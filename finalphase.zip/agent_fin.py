"""Better DQN-style agent scaffold for OBELIX (CPU).

This agent is *evaluation-only*: it loads pretrained weights from a file
placed next to agent.py inside the submission zip (weights.pth).
"""

# from __future__ import annotations
# from typing import List, Optional
# import os
# import numpy as np
# import torch
# import torch.nn as nn

# ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

# # 1. FIXED: Replaced standard DQN with DuelingDQN to match your latest training script
# class DuelingDQN(nn.Module):
#     def __init__(self, in_dim=18, n_actions=5):
#         super().__init__()
#         self.features = nn.Sequential(
#             nn.Linear(in_dim, 64),
#             nn.ReLU(),
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU()
#         )
#         self.value_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, 1)
#         )
#         self.advantage_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, n_actions)
#         )
#     def forward(self, x: torch.Tensor) -> torch.Tensor:
#         features = self.features(x)
#         values = self.value_stream(features)
#         advantages = self.advantage_stream(features)
#         qvals = values + (advantages - advantages.mean(dim=1, keepdim=True))
#         return qvals

# _model: Optional[DuelingDQN] = None
# _last_action: Optional[int] = None
# _repeat_count: int = 0

# _MAX_REPEAT = 2
# _CLOSE_Q_DELTA = 0.05

# def _load_once():
#     global _model
#     if _model is not None:
#         return
#     here = os.path.dirname(__file__)
#     wpath = os.path.join(here, "weights.pth")
#     if not os.path.exists(wpath):
#         raise FileNotFoundError(
#             "weights.pth not found next to agent.py. Train offline and include it in the submission zip."
#         )
    
#     # 2. FIXED: Instantiate the DuelingDQN instead of standard DQN
#     m = DuelingDQN()
    
#     sd = torch.load(wpath, map_location="cpu")
#     if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
#         sd = sd["state_dict"]
#     m.load_state_dict(sd, strict=True)
#     m.eval()
#     _model = m

# @torch.no_grad()
# def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
#     global _last_action, _repeat_count
#     _load_once()
#     x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
#     q = _model(x).squeeze(0).cpu().numpy()
#     best = int(np.argmax(q))

#     # 3. FIXED: Logical bug in action smoothing resolved
#     if _last_action is not None:
#         order = np.argsort(-q)
#         best_q, second_q = float(q[order[0]]), float(q[order[1]])
        
#         if (best_q - second_q) < _CLOSE_Q_DELTA:
#             # Only repeat the last action if it is one of the top 2 best choices right now
#             if _last_action in (order[0], order[1]) and _repeat_count < _MAX_REPEAT:
#                 best = _last_action
#                 _repeat_count += 1
#             else:
#                 _repeat_count = 0
#         else:
#             _repeat_count = 0

#     _last_action = best
#     return ACTIONS[best]


from __future__ import annotations
import os
import torch
import numpy as np
import torch.nn as nn
from collections import deque
from typing import List, Optional

# ──────────────────────────────────────────────
#  Constants & Action Spaces (Match Training)
# ──────────────────────────────────────────────
ALL_ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]
MOTION_ACTIONS: List[str] = ["FW", "L22", "R22"]

ROTATION_RECIPES = {
    "wall_no_box":   ["L45", "L45", "L45", "FW"],
    "wall_with_box": ["L45", "L45", "L45", "FW"],
    "escape_follow": ["L45", "L45", "L45", "FW"],
}

# ──────────────────────────────────────────────
#  Network Architecture (Match DuelingDRQN)
# ──────────────────────────────────────────────
class DuelingDRQN(nn.Module):
    def __init__(self, in_dim: int = 18, n_actions: int = len(MOTION_ACTIONS)):
        super().__init__()
        self.feature_layer = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.LayerNorm(256),
        )
        self.lstm = nn.LSTM(input_size=256, hidden_size=256, batch_first=True)
        self.advantage = nn.Sequential(
            nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, n_actions)
        )
        self.value = nn.Sequential(
            nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, 1)
        )

    def forward(self, x, hidden=None):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        x = self.feature_layer(x)
        output, next_hidden = self.lstm(x, hidden)
        last = output[:, -1, :]
        adv  = self.advantage(last)
        val  = self.value(last)
        q    = val + (adv - adv.mean(dim=1, keepdim=True))
        return q, next_hidden

# ──────────────────────────────────────────────
#  Agent State & Policy Logic
# ──────────────────────────────────────────────
_model: Optional[DuelingDRQN] = None
_history_len: int = 8  
_state_history: deque = deque(maxlen=_history_len)
_hidden: Optional[tuple[torch.Tensor, torch.Tensor]] = None 
_rotation_queue: deque[str] = deque()
_prev_stuck: bool = False
_is_pushing: bool = False

def _load_once():
    global _model
    if _model is not None:
        return
    
    here = os.path.dirname(__file__)
    # Try the default name from training script
    wpath = os.path.join(here, "final_w.pth")
    
    # Fallback to weights.pth if final_wei.pth isn't found
    if not os.path.exists(wpath):
        wpath = os.path.join(here, "final_w.pth")
        if not os.path.exists(wpath):
            raise FileNotFoundError(f"Weight file not found at {wpath}")

    m = DuelingDRQN(in_dim=18, n_actions=len(MOTION_ACTIONS))
    # Load state dict and set to eval
    m.load_state_dict(torch.load(wpath, map_location="cpu"))
    m.eval()
    _model = m

def _choose_rotation_recipe(ir_on: bool, stuck_on: bool, prev_stuck: bool) -> list[str] | None:
    """Exact logic from training script."""
    if stuck_on and not ir_on:
        return list(ROTATION_RECIPES["wall_no_box"])
    if stuck_on and ir_on:
        return list(ROTATION_RECIPES["wall_with_box"])
    if prev_stuck and not stuck_on:
        return list(ROTATION_RECIPES["escape_follow"])
    return None

@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _model, _state_history, _hidden, _rotation_queue, _prev_stuck, _is_pushing
    _load_once()
    
    # Maintain state history (sliding window of 8)
    if len(_state_history) == 0:
        for _ in range(_history_len): 
            _state_history.append(obs)
    else:
        _state_history.append(obs)
    
    ir_on = (obs[16] == 1)
    stuck_on = (obs[17] == 1)

    # 1. Macro-Action Override Check (Match Training)
    if not _rotation_queue:
        recipe = _choose_rotation_recipe(ir_on, stuck_on, _prev_stuck)
        if recipe:
            _rotation_queue.extend(recipe)

    if _rotation_queue:
        _prev_stuck = stuck_on
        return _rotation_queue.popleft()

    # 2. Pushing State Logic (Match Training)
    # Note: In training, is_pushing is updated AFTER the step, 
    # but here we approximate the behavior based on the current observation.
    if ir_on and not stuck_on:
        # If we see a box and aren't stuck, we are likely pushing
        _is_pushing = True
    elif not ir_on:
        _is_pushing = False

    # 3. Action Selection
    if _is_pushing and ir_on:
        # Force Forward during pushing (Match Training)
        action_str = "FW"
    else:
        # Neural Network Inference
        seq_t = torch.as_tensor(np.array(_state_history), dtype=torch.float32).unsqueeze(0)
        q_values, _hidden = _model(seq_t, _hidden)
        action_idx = q_values.argmax().item()
        action_str = MOTION_ACTIONS[action_idx]
    
    _prev_stuck = stuck_on
    return action_str

def reset_policy():
    """Called by the environment at the start of a new episode."""
    global _state_history, _hidden, _rotation_queue, _prev_stuck, _is_pushing
    _state_history.clear()
    _hidden = None
    _rotation_queue.clear()
    _prev_stuck = False
    _is_pushing = False