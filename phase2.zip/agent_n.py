# """Better DQN-style agent scaffold for OBELIX (CPU).

# This agent is *evaluation-only*: it loads pretrained weights from a file
# placed next to agent.py inside the submission zip (weights.pth).
# """

# from __future__ import annotations
# from typing import List, Optional
# import os
# import numpy as np
# import torch
# import torch.nn as nn

# ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

# # 1. FIXED: Replaced standard DQN with DuelingDQN to match your latest training script
# class DuelingDQN(nn.Module):
#     def __init__(self, in_dim=18, n_actions=5):
#         super().__init__()
#         self.features = nn.Sequential(
#             nn.Linear(in_dim, 64),
#             nn.ReLU(),
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU()
#         )
#         self.value_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, 1)
#         )
#         self.advantage_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, n_actions)
#         )
#     def forward(self, x: torch.Tensor) -> torch.Tensor:
#         features = self.features(x)
#         values = self.value_stream(features)
#         advantages = self.advantage_stream(features)
#         qvals = values + (advantages - advantages.mean(dim=1, keepdim=True))
#         return qvals

# _model: Optional[DuelingDQN] = None
# _last_action: Optional[int] = None
# _repeat_count: int = 0

# _MAX_REPEAT = 2
# _CLOSE_Q_DELTA = 0.05

# def _load_once():
#     global _model
#     if _model is not None:
#         return
#     here = os.path.dirname(__file__)
#     wpath = os.path.join(here, "weights.pth")
#     if not os.path.exists(wpath):
#         raise FileNotFoundError(
#             "weights.pth not found next to agent.py. Train offline and include it in the submission zip."
#         )
    
#     # 2. FIXED: Instantiate the DuelingDQN instead of standard DQN
#     m = DuelingDQN()
    
#     sd = torch.load(wpath, map_location="cpu")
#     if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
#         sd = sd["state_dict"]
#     m.load_state_dict(sd, strict=True)
#     m.eval()
#     _model = m

# @torch.no_grad()
# def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
#     global _last_action, _repeat_count
#     _load_once()
#     x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
#     q = _model(x).squeeze(0).cpu().numpy()
#     best = int(np.argmax(q))

#     # 3. FIXED: Logical bug in action smoothing resolved
#     if _last_action is not None:
#         order = np.argsort(-q)
#         best_q, second_q = float(q[order[0]]), float(q[order[1]])
        
#         if (best_q - second_q) < _CLOSE_Q_DELTA:
#             # Only repeat the last action if it is one of the top 2 best choices right now
#             if _last_action in (order[0], order[1]) and _repeat_count < _MAX_REPEAT:
#                 best = _last_action
#                 _repeat_count += 1
#             else:
#                 _repeat_count = 0
#         else:
#             _repeat_count = 0

#     _last_action = best
#     return ACTIONS[best]
# """Evaluation-only Dueling DQN agent for OBELIX.

# This agent loads pretrained weights from a file placed next to agent.py
# inside the submission zip (weights.pth).
# """

# from __future__ import annotations
# from typing import List, Optional
# import os
# import numpy as np

# # PyTorch Thread Limiting (Crucial for fixing Time Limit Exceeded)
# os.environ["OMP_NUM_THREADS"] = "1"
# os.environ["MKL_NUM_THREADS"] = "1"
# os.environ["OPENBLAS_NUM_THREADS"] = "1"

# import torch
# import torch.nn as nn

# torch.set_num_threads(1)
# torch.set_grad_enabled(False)

# ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

# class DuelingDQN(nn.Module):
#     def __init__(self, in_dim=18, n_actions=5):
#         super().__init__()
#         self.features = nn.Sequential(
#             nn.Linear(in_dim, 64),
#             nn.ReLU(),
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU()
#         )
#         self.value_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, 1)
#         )
#         self.advantage_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, n_actions)
#         )

#     def forward(self, x: torch.Tensor) -> torch.Tensor:
#         features = self.features(x)
#         values = self.value_stream(features)
#         advantages = self.advantage_stream(features)
#         qvals = values + (advantages - advantages.mean(dim=1, keepdim=True))
#         return qvals

# _model: Optional[DuelingDQN] = None
# _last_action: Optional[int] = None
# _repeat_count: int = 0

# _MAX_REPEAT = 2
# _CLOSE_Q_DELTA = 0.05

# def _load_once():
#     global _model
#     if _model is not None:
#         return
#     here = os.path.dirname(__file__)
#     wpath = os.path.join(here, "weights.pth")
#     if not os.path.exists(wpath):
#         raise FileNotFoundError(
#             "weights.pth not found next to agent.py. Train offline and include it in the submission zip."
#         )
    
#     m = DuelingDQN()
    
#     sd = torch.load(wpath, map_location="cpu")
#     if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
#         sd = sd["state_dict"]
#     m.load_state_dict(sd, strict=True)
#     m.eval()
    
#     # JIT compile for faster inference
#     _model = torch.jit.script(m)

# @torch.no_grad()
# def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
#     global _last_action, _repeat_count
#     _load_once()
    
#     # Pure PyTorch operations (faster than converting to numpy every frame)
#     x = torch.from_numpy(obs).float().unsqueeze(0)
#     q = _model(x).squeeze(0)
#     best = int(torch.argmax(q).item())

#     if _last_action is not None:
#         order = torch.argsort(q, descending=True)
#         best_idx = int(order[0].item())
#         second_idx = int(order[1].item())
        
#         best_q = float(q[best_idx].item())
#         second_q = float(q[second_idx].item())
        
#         if (best_q - second_q) < _CLOSE_Q_DELTA:
#             if _last_action in (best_idx, second_idx) and _repeat_count < _MAX_REPEAT:
#                 best = _last_action
#                 _repeat_count += 1
#             else:
#                 _repeat_count = 0
#         else:
#             _repeat_count = 0

#     _last_action = best
#     return ACTIONS[best]

# """Evaluation-only Dueling DQN (with LSTM) agent for OBELIX.

# This agent loads pretrained weights from a file placed next to agent.py
# inside the submission zip (weights.pth).
# """

# from __future__ import annotations
# from typing import List, Optional, Tuple
# import os
# import numpy as np

# # PyTorch Thread Limiting (Crucial for fixing Time Limit Exceeded)
# os.environ["OMP_NUM_THREADS"] = "1"
# os.environ["MKL_NUM_THREADS"] = "1"
# os.environ["OPENBLAS_NUM_THREADS"] = "1"

# import torch
# import torch.nn as nn

# torch.set_num_threads(1)
# torch.set_grad_enabled(False)

# ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

# class DuelingDQN(nn.Module):
#     def __init__(self, in_dim=18, n_actions=5):
#         super().__init__()
#         self.feature_layer = nn.Sequential(
#             nn.Linear(in_dim, 64),
#             nn.ReLU(),
#         )
#         # Add LSTM layer matching the train code
#         self.lstm = nn.LSTM(input_size=64, hidden_size=64, batch_first=True)
#         self.post_lstm = nn.Sequential(
#             nn.LayerNorm(64),
#             nn.ReLU()
#         )
#         self.value_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, 1)
#         )
#         self.advantage_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, n_actions)
#         )

#     # Added robust type hinting for the hidden state
#     def forward(self, x: torch.Tensor, hidden: Optional[Tuple[torch.Tensor, torch.Tensor]] = None) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
#         if x.dim() == 1:
#             x = x.unsqueeze(0).unsqueeze(0)
#         elif x.dim() == 2:
#             x = x.unsqueeze(1)

#         features = self.feature_layer(x)
        
#         lstm_out, hidden_out = self.lstm(features, hidden)
        
#         lstm_out = lstm_out.squeeze(1)
#         features_out = self.post_lstm(lstm_out)
        
#         values = self.value_stream(features_out)
#         advantages = self.advantage_stream(features_out)
#         qvals = values + (advantages - advantages.mean(dim=1, keepdim=True))
        
#         return qvals, hidden_out

# _model: Optional[DuelingDQN] = None
# _hidden_state: Optional[Tuple[torch.Tensor, torch.Tensor]] = None
# _last_action: Optional[int] = None
# _repeat_count: int = 0

# _MAX_REPEAT = 2
# _CLOSE_Q_DELTA = 0.05

# def _load_once():
#     global _model
#     if _model is not None:
#         return
#     here = os.path.dirname(__file__)
    
#     # FIX 1: Updated to match your actual file name
#     wpath = os.path.join(here, "last_weights.pth")
    
#     if not os.path.exists(wpath):
#         raise FileNotFoundError(
#             f"{wpath} not found next to agent.py. Train offline and include it in the submission zip."
#         )
    
#     m = DuelingDQN()
    
#     sd = torch.load(wpath, map_location="cpu")
#     if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
#         sd = sd["state_dict"]
#     m.load_state_dict(sd, strict=True)
#     m.eval()
    
#     # Bypassing JIT compilation (torch.jit.script) to avoid Tuple/LSTM serialization crashes
#     _model = m

# @torch.no_grad()
# def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
#     global _last_action, _repeat_count, _hidden_state, _model
#     _load_once()
    
#     # --- FIX 2: HIDDEN STATE RESET LOGIC ---
#     # TODO: Replace `False` with the logic to detect a new episode!
#     # Example: if obs[0] == 0.0:  (Assuming index 0 is a time step)
#     is_new_episode = False 
    
#     if is_new_episode: 
#         _hidden_state = None
#         _last_action = None
#         _repeat_count = 0
#     # ---------------------------------------
    
#     x = torch.from_numpy(obs).float().unsqueeze(0)
    
#     # Pass the hidden state back in, and update the global tracker
#     q, _hidden_state = _model(x, _hidden_state)
#     q = q.squeeze(0)
    
#     best = int(torch.argmax(q).item())

#     if _last_action is not None:
#         order = torch.argsort(q, descending=True)
#         best_idx = int(order[0].item())
#         second_idx = int(order[1].item())
        
#         best_q = float(q[best_idx].item())
#         second_q = float(q[second_idx].item())
        
#         if (best_q - second_q) < _CLOSE_Q_DELTA:
#             if _last_action in (best_idx, second_idx) and _repeat_count < _MAX_REPEAT:
#                 best = _last_action
#                 _repeat_count += 1
#             else:
#                 _repeat_count = 0
#         else:
#             _repeat_count = 0

#     _last_action = best
#     return ACTIONS[best]
"""Evaluation-only Actor (with LSTM) agent for OBELIX.

This agent loads pretrained weights from a file placed next to agent_n.py
inside the submission zip (last_weights.pth).
"""

from __future__ import annotations
from typing import List, Optional, Tuple
import os
import numpy as np

# PyTorch Thread Limiting (Crucial for fixing Time Limit Exceeded)
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"

import torch
import torch.nn as nn

torch.set_num_threads(1)
torch.set_grad_enabled(False)

ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

class PolicyNetwork(nn.Module):
    def __init__(self, in_dim=18, n_actions=5):
        super().__init__()
        self.feature_layer = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.ReLU(),
        )
        self.lstm = nn.LSTM(input_size=64, hidden_size=64, batch_first=True)
        self.post_lstm = nn.Sequential(
            nn.LayerNorm(64),
            nn.ReLU()
        )
        
        # Only the Actor remains
        self.actor = nn.Sequential(
            nn.Linear(64, 64),
            nn.LayerNorm(64),
            nn.ReLU(),
            nn.Linear(64, n_actions)
        )

    def forward(self, x: torch.Tensor, hidden: Optional[Tuple[torch.Tensor, torch.Tensor]] = None) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        # Expect x to be shape: [Batch, Sequence, Features]
        features = self.feature_layer(x)
        lstm_out, hidden_out = self.lstm(features, hidden)
        
        features_out = self.post_lstm(lstm_out)
        
        action_logits = self.actor(features_out)
        
        return action_logits, hidden_out


_model: Optional[PolicyNetwork] = None
_hidden_state: Optional[Tuple[torch.Tensor, torch.Tensor]] = None
_last_action: Optional[int] = None
_repeat_count: int = 0
_step_count: int = 0  # Added to track steps for resetting hidden state

_MAX_REPEAT = 2
_CLOSE_LOGIT_DELTA = 0.5 

def _load_once():
    global _model
    if _model is not None:
        return
    here = os.path.dirname(__file__)
    
    # Strictly check for last_weights.pth
    wpath = os.path.join(here, "last_weights.pth")
        
    if not os.path.exists(wpath):
        raise FileNotFoundError(
            f"last_weights.pth not found next to agent_n.py. Train offline and include it in the submission zip."
        )
    
    m = PolicyNetwork()
    
    sd = torch.load(wpath, map_location="cpu")
    if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
        sd = sd["state_dict"]
    m.load_state_dict(sd, strict=True)
    m.eval()
    
    _model = m

@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _last_action, _repeat_count, _hidden_state, _model, _step_count
    _load_once()
    
    # --- HIDDEN STATE RESET LOGIC ---
    is_new_episode = False 
    
    # 1. Reset if we hit the maximum steps for an episode (1000 from your training script)
    if _step_count >= 1000:
        is_new_episode = True
        
    # 2. TODO: Early termination check! 
    # If the episode can end early (e.g., collision), check for a resetting value in `obs`.
    # For example, if obs[0] is the agent's speed or timer that drops to 0 on reset:
    # if obs[0] == 0.0: 
    #     is_new_episode = True
    
    if is_new_episode or _step_count == 0: 
        _hidden_state = None
        _last_action = None
        _repeat_count = 0
        _step_count = 0
        
    _step_count += 1
    # ---------------------------------------
    
    # Format input exactly as the training script: [Batch=1, Seq=1, Features=18]
    x = torch.from_numpy(obs).float().view(1, 1, -1)
    
    logits, _hidden_state = _model(x, _hidden_state)
    
    # Squeeze out the batch and sequence dimensions so logits is a flat 1D tensor [5]
    logits = logits.squeeze() 
    
    best = int(torch.argmax(logits).item())

    # Action smoothing logic
    if _last_action is not None:
        order = torch.argsort(logits, descending=True)
        best_idx = int(order[0].item())
        second_idx = int(order[1].item())
        
        best_logit = float(logits[best_idx].item())
        second_logit = float(logits[second_idx].item())
        
        if (best_logit - second_logit) < _CLOSE_LOGIT_DELTA:
            if _last_action in (best_idx, second_idx) and _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0

    _last_action = best
    return ACTIONS[best]