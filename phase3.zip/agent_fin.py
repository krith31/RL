"""Better DQN-style agent scaffold for OBELIX (CPU).

This agent is *evaluation-only*: it loads pretrained weights from a file
placed next to agent.py inside the submission zip (weights.pth).
"""

# from __future__ import annotations
# from typing import List, Optional
# import os
# import numpy as np
# import torch
# import torch.nn as nn

# ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

# # 1. FIXED: Replaced standard DQN with DuelingDQN to match your latest training script
# class DuelingDQN(nn.Module):
#     def __init__(self, in_dim=18, n_actions=5):
#         super().__init__()
#         self.features = nn.Sequential(
#             nn.Linear(in_dim, 64),
#             nn.ReLU(),
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU()
#         )
#         self.value_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, 1)
#         )
#         self.advantage_stream = nn.Sequential(
#             nn.Linear(64, 64),
#             nn.LayerNorm(64),
#             nn.ReLU(),
#             nn.Linear(64, n_actions)
#         )
#     def forward(self, x: torch.Tensor) -> torch.Tensor:
#         features = self.features(x)
#         values = self.value_stream(features)
#         advantages = self.advantage_stream(features)
#         qvals = values + (advantages - advantages.mean(dim=1, keepdim=True))
#         return qvals

# _model: Optional[DuelingDQN] = None
# _last_action: Optional[int] = None
# _repeat_count: int = 0

# _MAX_REPEAT = 2
# _CLOSE_Q_DELTA = 0.05

# def _load_once():
#     global _model
#     if _model is not None:
#         return
#     here = os.path.dirname(__file__)
#     wpath = os.path.join(here, "weights.pth")
#     if not os.path.exists(wpath):
#         raise FileNotFoundError(
#             "weights.pth not found next to agent.py. Train offline and include it in the submission zip."
#         )
    
#     # 2. FIXED: Instantiate the DuelingDQN instead of standard DQN
#     m = DuelingDQN()
    
#     sd = torch.load(wpath, map_location="cpu")
#     if isinstance(sd, dict) and "state_dict" in sd and isinstance(sd["state_dict"], dict):
#         sd = sd["state_dict"]
#     m.load_state_dict(sd, strict=True)
#     m.eval()
#     _model = m

# @torch.no_grad()
# def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
#     global _last_action, _repeat_count
#     _load_once()
#     x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
#     q = _model(x).squeeze(0).cpu().numpy()
#     best = int(np.argmax(q))

#     # 3. FIXED: Logical bug in action smoothing resolved
#     if _last_action is not None:
#         order = np.argsort(-q)
#         best_q, second_q = float(q[order[0]]), float(q[order[1]])
        
#         if (best_q - second_q) < _CLOSE_Q_DELTA:
#             # Only repeat the last action if it is one of the top 2 best choices right now
#             if _last_action in (order[0], order[1]) and _repeat_count < _MAX_REPEAT:
#                 best = _last_action
#                 _repeat_count += 1
#             else:
#                 _repeat_count = 0
#         else:
#             _repeat_count = 0

#     _last_action = best
#     return ACTIONS[best]

from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn
from collections import deque

ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]

class PolicyNetwork(nn.Module):
    def __init__(self, in_dim=54, n_actions=5): # Updated to 54 for 3-frame stack
        super().__init__()
        self.feature_layer = nn.Sequential(
            nn.Linear(in_dim, 256),
            nn.ReLU(),
            nn.LayerNorm(256)
        )
        self.lstm = nn.LSTM(input_size=256, hidden_size=256, batch_first=True)
        
        self.policy_head = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, n_actions),
            nn.Softmax(dim=-1)
        )
        self.value_head = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, x, hidden=None):
        if x.dim() == 1:
            x = x.unsqueeze(0).unsqueeze(0)
        elif x.dim() == 2:
            x = x.unsqueeze(1)
            
        x = self.feature_layer(x)
        x, hidden = self.lstm(x, hidden)
        x = x[:, -1, :] 
        
        probs = self.policy_head(x)
        value = self.value_head(x)
        return probs, value, hidden

_model: Optional[PolicyNetwork] = None
_hidden: Optional[tuple[torch.Tensor, torch.Tensor]] = None
_stack: deque = deque(maxlen=3)
_step_count: int = 0

def _load_once():
    global _model
    if _model is not None:
        return
    here = os.path.dirname(__file__)
    wpath = os.path.join(here, "weights.pth")
    if not os.path.exists(wpath):
        wpath = os.path.join(here, "last_weights.pth")
    
    if not os.path.exists(wpath):
        raise FileNotFoundError(f"Weight file not found at {wpath}")
    
    m = PolicyNetwork()
    sd = torch.load(wpath, map_location="cpu")
    
    if isinstance(sd, dict) and "state_dict" in sd:
        sd = sd["state_dict"]
        
    m.load_state_dict(sd, strict=False)
    m.eval()
    _model = m

@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _hidden, _model, _step_count, _stack
    _load_once()
    
    # 1. Handle Frame Stacking
    if len(_stack) == 0:
        for _ in range(3): _stack.append(obs)
    else:
        _stack.append(obs)
    
    # 2. Reset hidden state and stack for new episodes
    # Evaluator typically resets every 1000-2000 steps
    if _step_count >= 2000: 
        _hidden = None
        _stack.clear()
        for _ in range(3): _stack.append(obs)
        _step_count = 0

    # 3. Concatenate the stack (18 * 3 = 54)
    stacked_obs = np.concatenate(list(_stack))
    x = torch.as_tensor(stacked_obs, dtype=torch.float32)
    
    # 4. Model Inference
    probs, _, next_hidden = _model(x, _hidden)
    _hidden = next_hidden
    _step_count += 1
    
    best = torch.argmax(probs, dim=1).item()
    return ACTIONS[best]